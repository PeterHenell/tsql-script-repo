use master;
go

drop database [target];
go

create database [target]
	ON (NAME = [target], FILENAME = 'c:\temp\TARGET.MDF', SIZE = 5GB)
	LOG ON (NAME = [target_log], FILENAME = 'c:\temp\TARGET_LOG.LDF', SIZE = 1GB);
go

alter database [target]
	set recovery simple;
go

use [target];
go

create queue [target];
create service [target] on queue [target] ([DEFAULT]);
go

grant send on service::[target] to [Public];
go

create route [sender]
	with service_name = 'sender',
	address = 'tcp://SELOAN10';
go

CREATE QUEUE [Initiator];
CREATE SERVICE [Initiator] ON QUEUE [Initiator];
GO

-- This procedure loads the test queue qith the 
--    number of messages and conversations passed in
--

CREATE PROCEDURE LoadQueueReceivePerfBlog
      @conversationCount INT,
      @messagesPerConversation INT,
      @payload VARBINARY(MAX)
AS
BEGIN
      SET NOCOUNT ON;
      DECLARE @batchCount INT;
      SELECT @batchCount = 0;
      DECLARE @h UNIQUEIDENTIFIER;
      BEGIN TRANSACTION;
      WHILE @conversationCount > 0
      BEGIN
            BEGIN DIALOG CONVERSATION @h
                  FROM SERVICE [Initiator]
                  TO SERVICE N'target', 'current database'
                  WITH ENCRYPTION = OFF;
            DECLARE @messageCount INT;
            SELECT @messageCount = 0;
            WHILE @messageCount < @messagesPerConversation
            BEGIN
                  SEND ON CONVERSATION @h (@payload);
                  SELECT @messageCount = @messageCount + 1,
                        @batchCount = @batchCount + 1;
                  IF @batchCount >= 100
                  BEGIN
                        COMMIT;
                        SELECT @batchCount = 0;
                        BEGIN TRANSACTION;
                  END
            END
            SELECT @conversationCount = @conversationCount-1
      END
      COMMIT;
END
GO

use master;
go