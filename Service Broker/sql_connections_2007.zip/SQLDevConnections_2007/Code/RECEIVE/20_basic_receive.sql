use [target];
go

if exists (select * from sys.procedures where name = 'BasicReceive')
begin
	drop procedure [BasicReceive];
end
GO

CREATE PROCEDURE [BasicReceive]
AS
BEGIN
      SET NOCOUNT ON;
      DECLARE @h UNIQUEIDENTIFIER;
      DECLARE @messageTypeName SYSNAME;
      DECLARE @payload VARBINARY(MAX);

      WHILE (1=1)
      BEGIN
            BEGIN TRANSACTION;
            WAITFOR(RECEIVE TOP(1) 
                  @h = conversation_handle,
                  @messageTypeName = message_type_name,
                  @payload = message_body
                  FROM [target]), TIMEOUT 500;
            IF (@@ROWCOUNT = 0)
            BEGIN
                  COMMIT;
                  BREAK;
            END

            -- Some basic processing. Send back an echo reply
            --

            IF N'DEFAULT' = @messageTypeName
            BEGIN
                  SEND ON CONVERSATION @h (@payload);
            END
            ELSE IF N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog' = @messageTypeName
            BEGIN
                  END CONVERSATION @h;
            END
            ELSE IF N'http://schemas.microsoft.com/SQL/ServiceBroker/Error' = @messageTypeName
            BEGIN
                  -- Log the received error into ERRORLOG and system Event Log (eventvwr.exe)
                  DECLARE @h_string NVARCHAR(100);
                  DECLARE @error_message NVARCHAR(4000);
                  SELECT @h_string = CAST(@h AS NVARCHAR(100)), @error_message = CAST(@payload AS NVARCHAR(4000));
                  RAISERROR (N'Conversation %s was ended with error %s', 10, 1, @h_string, @error_message) WITH LOG;
                  END CONVERSATION @h;
            END
            COMMIT;
      END
END
GO
