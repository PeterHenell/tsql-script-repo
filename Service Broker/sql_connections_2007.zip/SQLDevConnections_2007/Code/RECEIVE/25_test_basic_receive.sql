use [master];
go

alter database [target] set new_broker;

USE [target];
GO

DECLARE @payload VARBINARY(MAX);
SELECT @payload = CAST(N'<Test/>' AS VARBINARY(MAX));
EXEC LoadQueueReceivePerfBlog 100,100, @payload;
GO

DECLARE @msgCount FLOAT;
DECLARE @startTime DATETIME;
DECLARE @endTime DATETIME;

SELECT @msgCount = COUNT(*) FROM [target];
SELECT @startTime = GETDATE();

EXEC [BasicReceive];

SELECT @endTime = GETDATE();
SELECT @startTime as [Start], 
      @endTime as [End], 
      @msgCount as [Count],
      DATEDIFF(second, @startTime, @endTime) as [Duration],
      @msgCount/DATEDIFF(millisecond, @startTime, @endTime)*1000 as [Rate];
GO

/*
2007-03-24 15:27:39.670	2007-03-24 15:28:04.043	10000	25	410.290075083084
2007-03-24 15:28:46.403	2007-03-24 15:29:10.140	10000	24	421.300977418268
*/