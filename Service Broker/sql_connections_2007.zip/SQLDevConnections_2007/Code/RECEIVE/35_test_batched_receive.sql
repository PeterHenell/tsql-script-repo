use [master];
go

alter database [target] set new_broker;

USE [target];
GO

DECLARE @payload VARBINARY(MAX);
SELECT @payload = CAST(N'<Test/>' AS VARBINARY(MAX));
EXEC LoadQueueReceivePerfBlog 100,100, @payload;
GO

DECLARE @msgCount FLOAT;
DECLARE @startTime DATETIME;
DECLARE @endTime DATETIME;

SELECT @msgCount = COUNT(*) FROM [target];
SELECT @startTime = GETDATE();

EXEC [BatchedReceive];

SELECT @endTime = GETDATE();
SELECT @startTime as [Start], 
      @endTime as [End], 
      @msgCount as [Count],
      DATEDIFF(second, @startTime, @endTime) as [Duration],
      @msgCount/DATEDIFF(millisecond, @startTime, @endTime)*1000 as [Rate];
GO

/*
2007-03-24 15:33:57.920	2007-03-24 15:34:19.030	10000	22	473.709142586452
2007-03-24 15:34:49.560	2007-03-24 15:35:09.060	10000	20	512.820512820513
*/