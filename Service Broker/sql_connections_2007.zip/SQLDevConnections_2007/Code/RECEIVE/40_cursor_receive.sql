use [target];
go

IF EXISTS(SELECT * FROM sys.procedures WHERE NAME = N'CursorReceive')
      DROP PROCEDURE [CursorReceive];
GO

CREATE PROCEDURE [CursorReceive]
AS
BEGIN
      SET NOCOUNT ON;
      DECLARE @tableMessages TABLE (
            queuing_order BIGINT,
            conversation_handle UNIQUEIDENTIFIER,
            message_type_name SYSNAME,
            message_body VARBINARY(MAX));
      
      -- Create cursor over the table variable
      -- Use the queueing_order column to 
      -- preserve the message order
      --
      DECLARE cursorMessages 
            CURSOR FORWARD_ONLY READ_ONLY
            FOR SELECT conversation_handle,
                  message_type_name,
                  message_body
                  FROM @tableMessages
                  ORDER BY queuing_order;
 
      DECLARE @h UNIQUEIDENTIFIER;
      DECLARE @messageTypeName SYSNAME;
      DECLARE @payload VARBINARY(MAX);
 
      WHILE (1=1)
      BEGIN
            BEGIN TRANSACTION;
            WAITFOR(RECEIVE
                  queuing_order,
                  conversation_handle,
                  message_type_name,
                  message_body
                  FROM [target]
                  INTO @tableMessages), TIMEOUT 1000;
            IF (@@ROWCOUNT = 0)
            BEGIN
                  COMMIT;
                  BREAK;
            END
 
            OPEN cursorMessages;
            WHILE (1=1)
            BEGIN
                  FETCH NEXT FROM cursorMessages
                        INTO @h, @messageTypeName, @payload;
                  IF (@@FETCH_STATUS != 0)
                        BREAK;
                        
                  -- Some basic processing. Send back an echo reply
                  --
                  IF N'DEFAULT' = @messageTypeName
                  BEGIN
                        SEND ON CONVERSATION @h (@payload);
                  END
                  ELSE IF N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog' = @messageTypeName
                  BEGIN
                        END CONVERSATION @h;
                  END
                  ELSE IF N'http://schemas.microsoft.com/SQL/ServiceBroker/Error' = @messageTypeName
                  BEGIN
                        -- Log the received error into ERRORLOG and system Event Log (eventvwr.exe)
                        DECLARE @h_string NVARCHAR(100);
                        DECLARE @error_message NVARCHAR(4000);
                        SELECT @h_string = CAST(@h AS NVARCHAR(100)), @error_message = CAST(@payload AS NVARCHAR(4000));
                        RAISERROR (N'Conversation %s was ended with error %s', 10, 1, @h_string, @error_message) WITH LOG;
                        END CONVERSATION @h;
                  END
            END
            CLOSE cursorMessages;
            DELETE FROM @tableMessages;
            COMMIT;
      END
      DEALLOCATE cursorMessages;
END
GO