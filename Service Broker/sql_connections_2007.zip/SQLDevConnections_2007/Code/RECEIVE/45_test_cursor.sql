use [master];
go

alter database [target] set new_broker;

USE [target];
GO

DECLARE @payload VARBINARY(MAX);
SELECT @payload = CAST(N'<Test/>' AS VARBINARY(MAX));
EXEC LoadQueueReceivePerfBlog 100,100, @payload;
GO

DECLARE @msgCount FLOAT;
DECLARE @startTime DATETIME;
DECLARE @endTime DATETIME;

SELECT @msgCount = COUNT(*) FROM [target];
SELECT @startTime = GETDATE();

EXEC [CursorReceive];

SELECT @endTime = GETDATE();
SELECT @startTime as [Start], 
      @endTime as [End], 
      @msgCount as [Count],
      DATEDIFF(second, @startTime, @endTime) as [Duration],
      @msgCount/DATEDIFF(millisecond, @startTime, @endTime)*1000 as [Rate];
GO

/*
2007-03-24 15:39:27.403	2007-03-24 15:39:32.640	10000	5	1909.85485103132
2007-03-24 15:39:56.327	2007-03-24 15:40:00.060	10000	4	2678.81060809001
*/