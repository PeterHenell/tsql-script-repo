use [master];
go

USE [target];
GO
 
IF EXISTS(SELECT * FROM sys.tables WHERE NAME = N'PayloadData')
      DROP TABLE [PayloadData];
GO
 
CREATE TABLE [PayloadData] (
      [Id] INT NOT NULL IDENTITY,
      [DateTime] DATETIME,
      [Payload] NVARCHAR(MAX),
      [User] NVARCHAR(256),
      [Original] XML);
GO
 
IF EXISTS(SELECT * FROM sys.procedures WHERE NAME = N'RowsetDatagram')
      DROP PROCEDURE [RowsetDatagram];
GO
 
CREATE PROCEDURE [RowsetDatagram]
AS
BEGIN
      SET NOCOUNT ON;
      DECLARE @tableMessages TABLE (
            queuing_order BIGINT,
            conversation_handle UNIQUEIDENTIFIER,
            message_type_name SYSNAME,
            payload XML);--([DatagramSchemaCollection]));
      
      WHILE (1=1)
      BEGIN
            BEGIN TRANSACTION;
            WAITFOR(RECEIVE 
                  queuing_order,
                  conversation_handle,
                  message_type_name,
                  CAST(message_body AS XML) AS payload
                  FROM [Target]
                  INTO @tableMessages), TIMEOUT 500;
            IF (@@ROWCOUNT = 0)
            BEGIN
                  COMMIT;
                  BREAK;
            END
 
            -- Rowset based datagram processing:
            -- Extract the XML attributes and insert into table
            ;WITH XMLNAMESPACES (DEFAULT 'http://tempuri.org/RemusRusanu/Blog/10/14/2006/Datagram') 
            INSERT INTO [PayloadData] 
                  ([DateTime], [Payload], [User], [Original])
                  SELECT payload.value(N'(/Datagram/@date-time)[1]', 'DATETIME'),
                        payload.value(N'(/Datagram/@payload)[1]', 'NVARCHAR(MAX)'),
                        payload.value(N'(/Datagram/@user)[1]', 'NVARCHAR(256)'),
                        payload
                        FROM @tableMessages
                        WHERE message_type_name = N'DEFAULT'
                        ORDER BY queuing_order;
            COMMIT;
            DELETE FROM @tableMessages;
      END
END
GO