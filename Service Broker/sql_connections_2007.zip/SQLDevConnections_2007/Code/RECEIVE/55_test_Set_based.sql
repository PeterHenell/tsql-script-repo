use [master];
go

alter database [target] set new_broker;

USE [target];
GO

DELETE FROM PayloadData;
GO

DECLARE @xmlPayload XML;
DECLARE @payload VARBINARY(MAX);
WITH XMLNAMESPACES (DEFAULT 'http://tempuri.org/RemusRusanu/Blog/10/14/2006/Datagram') 
SELECT @xmlPayload = (SELECT GETDATE() AS [@date-time],
            SUSER_SNAME() AS [@user],
            N'Some Data' AS [@payload]
            FOR XML PATH(N'Datagram'), TYPE);
SELECT @payload = CAST(@xmlPayload AS VARBINARY(MAX));
EXEC LoadQueueReceivePerfBlog 100,500, @payload;
GO

DECLARE @msgCount FLOAT;
DECLARE @startTime DATETIME;
DECLARE @endTime DATETIME;

SELECT @msgCount = COUNT(*) FROM [target];
SELECT @startTime = GETDATE();

EXEC [RowsetDatagram];

SELECT @endTime = GETDATE();
SELECT @startTime as [Start], 
      @endTime as [End], 
      @msgCount as [Count],
      DATEDIFF(second, @startTime, @endTime) as [Duration],
      @msgCount/DATEDIFF(millisecond, @startTime, @endTime)*1000 as [Rate];
GO

/*
2007-03-24 15:52:44.483	2007-03-24 15:53:01.077	50000	17	3013.31886940276
2007-03-24 15:50:41.030	2007-03-24 15:50:56.983	50000	15	3134.20673227606
*/