use [master]
go

drop database [sender]
go

create database [sender]
	ON (NAME = [sender], FILENAME = 'c:\temp\SENDER.MDF', SIZE = 5GB)
	LOG ON (NAME = [sender_log], FILENAME = 'c:\temp\SENDER_LOG.LDF', SIZE = 1GB);
go

alter database [sender]
	set recovery simple;
go

use [sender];
go

create queue [sender];
create service [sender] on queue [sender];
go

create route [target]
	with service_name = 'target',
	address = 'tcp://remusr10';
go

use master;
go