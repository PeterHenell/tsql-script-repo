use master;
go

drop database [target];
go

create database [target]
	ON (NAME = [target], FILENAME = 'c:\temp\TARGET.MDF', SIZE = 5GB)
	LOG ON (NAME = [target_log], FILENAME = 'c:\temp\TARGET_LOG.LDF', SIZE = 1GB);
go

alter database [target]
	set recovery simple;
go

use [target];
go

create queue [target];
create service [target] on queue [target] ([DEFAULT]);
go

grant send on service::[target] to [Public];
go

create route [sender]
	with service_name = 'sender',
	address = 'tcp://SELOAN10';
go