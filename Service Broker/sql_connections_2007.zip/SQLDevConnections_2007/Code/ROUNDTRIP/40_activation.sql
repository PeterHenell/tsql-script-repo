use [target];
go

alter queue [target] 
	with activation (
		status = on,
		procedure_name = [CursorReceive],
		max_queue_readers = 2,
		execute as owner);
go