alter database sender set new_broker;
go

use sender;
go

declare @h uniqueidentifier;
declare @i int;
declare @payload varchar(max);
declare @xmitrows int;
declare @recvrows int;
declare @start datetime;
declare @send datetime;
declare @roundtrip datetime;
declare @enqueue datetime;
select @start = getdate(), @i = 0, @payload = replicate(0x00,1024);

-- Reuse dialogs, 100 msgs/dialog
-- Exlicit transactions, batch 100 msgs/transaction

begin transaction
while @i < 5000
begin
	begin dialog conversation @h
		from service [sender]
		to service 'target'
		with encryption = off;
	send on conversation @h (@payload);
	select @i = @i + 1;
	if @i % 100 = 0
	begin
		commit;
		begin transaction;
	end
end
commit;

select @enqueue = getdate();

-- Measure xmit drainning
--
select @xmitrows = p.rows
      from sys.partitions p
	  where p.object_id = 68

while (@xmitrows > 0)
begin
	waitfor delay '00:00:01';
	select @xmitrows = p.rows
		  from sys.partitions p
		  where p.object_id = 68
end
select @send = getdate();

-- Masure roundtrip app response time
--
select @recvrows = p.rows
	from sys.partitions p
	join sys.objects o on p.object_id = o.object_id
	join sys.objects q on q.object_id = o.parent_object_id
	where q.name = 'sender'
	and p.index_id = 1;
while (@recvrows < @i)
begin
	waitfor delay '00:00:01';
	select @recvrows = p.rows
		from sys.partitions p
		join sys.objects o on p.object_id = o.object_id
		join sys.objects q on q.object_id = o.parent_object_id
		where q.name = 'sender'
		and p.index_id = 1;
end

select @roundtrip = getdate();

select @start, @enqueue, @i, datediff(second, @start, @enqueue) as duration, @i*1000.00/datediff(ms, @start, @enqueue) as xmitq_rate;
select @start, @send, @i, datediff(second, @start, @send) as duration, @i*1000.00/datediff(ms, @start, @send) as rate;
select @start, @roundtrip, @i, datediff(second, @start, @roundtrip) as duration, @i*1000.00/datediff(ms, @start, @roundtrip) as rate;

/*
2007-03-24 16:45:37.560	2007-03-24 16:45:56.217	5000	19	268.0102915951972
2007-03-24 16:44:51.640	2007-03-24 16:45:12.170	5000	21	243.5460301997077
*/