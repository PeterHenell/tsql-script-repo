use [master];
go

alter database [target] set new_broker;
go
