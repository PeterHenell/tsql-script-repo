use master;
create master key encryption by password='Password#1234';
create certificate SELOAN10 with subject = 'SELOAN10';
go

create endpoint broker
	state = started
	as tcp (listener_port = 4022)
	for service_broker (authentication = certificate [seloan10], encryption = disabled);
go

grant connect on endpoint::broker to [Public];
go