use master;
create master key encryption by password='Password#1234';
create certificate REMUSR10 with subject = 'REMUSR10';
go

create endpoint broker
	state = started
	as tcp (listener_port = 4022)
	for service_broker (authentication = certificate [REMUSR10], encryption = disabled);
go

grant connect on endpoint::broker to [Public];
go