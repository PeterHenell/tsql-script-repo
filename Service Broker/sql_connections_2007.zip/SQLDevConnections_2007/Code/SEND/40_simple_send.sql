alter database sender set new_broker;
go

use sender;
go

declare @h uniqueidentifier;
declare @i int;
declare @payload varchar(max);
declare @xmitrows int;
declare @start datetime;
declare @end datetime;
declare @enqueue datetime;
select @start = getdate(), @i = 0, @payload = replicate(0x00,1024);

-- Send one message per dialog
-- No explicit transactions

while @i < 25000
begin
	begin dialog conversation @h
		from service [sender]
		to service 'target'
		with encryption = off;
	send on conversation @h (@payload);
	select @i = @i + 1;
end

select @enqueue = getdate();

-- 68 - object_id for sysxmitwq, the hidden table
--	behind sys.transmission_queue
--
select @xmitrows = p.rows
      from sys.partitions p
	  where p.object_id = 68

while (@xmitrows > 0)
begin
	waitfor delay '00:00:01';
	select @xmitrows = p.rows
		  from sys.partitions p
		  where p.object_id = 68
end
select @end = getdate();
select @start, @enqueue, @i, datediff(second, @start, @enqueue) as duration, @i*1000.00/datediff(ms, @start, @enqueue) as xmitq_rate;
select @start, @end, @i, datediff(second, @start, @end) as duration, @i*1000.00/datediff(ms, @start, @end) as rate;

/*
2007-03-23 15:27:53.360	2007-03-23 15:29:17.793	50000	84	592.1855198796679
2007-03-23 15:27:53.360	2007-03-23 15:30:09.703	50000	136	366.7221639541450
*/