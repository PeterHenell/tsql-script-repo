alter database sender set new_broker;
go

use sender;
go

declare @h uniqueidentifier;
declare @i int;
declare @payload varchar(max);
declare @xmitrows int;
declare @start datetime;
declare @end datetime;
declare @enqueue datetime;
select @start = getdate(), @i = 0, @payload = replicate(0x00,1024);

-- Reuse dialogs, send 100 msgs/dialog
-- No explicit transactions

begin dialog conversation @h
	from service [sender]
	to service 'target'
	with encryption = off;
while @i < 50000
begin
	send on conversation @h (@payload);
	select @i = @i + 1;
	if @i % 100 = 0
	begin
		begin dialog conversation @h
			from service [sender]
			to service 'target'
			with encryption = off;
	end
end

select @enqueue = getdate();

select @xmitrows = p.rows
      from sys.partitions p
	  where p.object_id = 68

while (@xmitrows > 0)
begin
	waitfor delay '00:00:01';
	select @xmitrows = p.rows
		  from sys.partitions p
		  where p.object_id = 68
end
select @end = getdate();
select @start, @enqueue, @i, datediff(second, @start, @enqueue) as duration, @i*1000.00/datediff(ms, @start, @enqueue) as xmitq_rate;
select @start, @end, @i, datediff(second, @start, @end) as duration, @i*1000.00/datediff(ms, @start, @end) as rate;

/*
2007-03-23 15:40:26.387	2007-03-23 15:41:04.037	50000	38	1328.0212483399734
2007-03-23 15:40:26.387	2007-03-23 15:41:06.033	50000	40	1261.1612773041416
*/