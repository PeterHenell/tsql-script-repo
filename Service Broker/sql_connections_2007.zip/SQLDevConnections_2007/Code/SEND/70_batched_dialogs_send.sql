alter database sender set new_broker;
go

use sender;
go

declare @h uniqueidentifier;
declare @i int;
declare @payload varchar(max);
declare @xmitrows int;
declare @start datetime;
declare @end datetime;
declare @enqueue datetime;
select @start = getdate(), @i = 0, @payload = replicate(0x00,1024);

-- Reuse dialogs, 100 msgs/dialog
-- Exlicit transactions, batch 100 msgs/transaction

begin transaction
begin dialog conversation @h
	from service [sender]
	to service 'target'
	with encryption = off;
while @i < 50000
begin
	send on conversation @h (@payload);
	select @i = @i + 1;
	if @i % 100 = 0
	begin
		commit;
		begin transaction;
		begin dialog conversation @h
			from service [sender]
			to service 'target'
			with encryption = off;
	end
end
commit;

select @enqueue = getdate();

select @xmitrows = p.rows
      from sys.partitions p
	  where p.object_id = 68

while (@xmitrows > 0)
begin
	waitfor delay '00:00:01';
	select @xmitrows = p.rows
		  from sys.partitions p
		  where p.object_id = 68
end
select @end = getdate();
select @start, @enqueue, @i, datediff(second, @start, @enqueue) as duration, @i*1000.00/datediff(ms, @start, @enqueue) as xmitq_rate;
select @start, @end, @i, datediff(second, @start, @end) as duration, @i*1000.00/datediff(ms, @start, @end) as rate;

/*
2007-03-23 15:42:49.110	2007-03-23 15:42:57.367	50000	8	6056.2015503875968
2007-03-23 15:42:49.110	2007-03-23 15:43:29.333	50000	40	1243.0698853889565
*/