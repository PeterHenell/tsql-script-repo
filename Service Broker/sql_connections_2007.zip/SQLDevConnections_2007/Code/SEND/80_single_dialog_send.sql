alter database sender set new_broker;
go

use sender;
go

declare @h uniqueidentifier;
declare @i int;
declare @payload varchar(max);
declare @xmitrows int;
declare @start datetime;
declare @end datetime;
declare @enqueue datetime;
select @start = getdate(), @i = 0, @payload = replicate(0x00,1024);

begin transaction
begin dialog conversation @h
	from service [sender]
	to service 'target'
	with encryption = off;
while @i < 50000
begin
	send on conversation @h (@payload);
	select @i = @i + 1;
	if @i % 100 = 0
	begin
		commit;
		begin transaction;
	end
end
commit;

select @enqueue = getdate();

select @xmitrows = p.rows
      from sys.partitions p
	  where p.object_id = 68

while (@xmitrows > 0)
begin
	waitfor delay '00:00:01';
	select @xmitrows = p.rows
		  from sys.partitions p
		  where p.object_id = 68
end
select @end = getdate();
select @start, @enqueue, @i, datediff(second, @start, @enqueue) as duration, @i*1000.00/datediff(ms, @start, @enqueue) as xmitq_rate;
select @start, @end, @i, datediff(second, @start, @end) as duration, @i*1000.00/datediff(ms, @start, @end) as rate;

/*
2007-03-23 15:44:45.290	2007-03-23 15:44:54.203	50000	9	5609.7834623583529
2007-03-23 15:44:45.290	2007-03-23 15:45:17.257	50000	32	1564.1619220421698
*/